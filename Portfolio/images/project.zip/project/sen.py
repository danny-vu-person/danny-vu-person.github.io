from pylab import * #for multiplication and exponent functions
import os.path

directory = os.path.dirname(os.path.abspath(__file__))
# Open the file

labels = []# labels for slices on pi chart
fracs = []#data from http://www.library.ca.gov/crb/08/08-007.pdf

filename = os.path.join(directory, 'tally_chart'+'.csv')
datafile = open(filename,'r')
# Go through all the names that year
for line in datafile:
    name, nothing, number = line.split(',')
    if name == "positive":
        labels += [name]
        fracs += [number]    
    if name == "neutral":
        labels += [name]
        fracs += [number]
    if name == "negative":
        labels += [name]
        fracs += [number]
    if name == "outlier":
        labels += [name]
        fracs += [number]
#Close that year's file
datafile.close()
     
figure(1, figsize=(10,10))#size and amount of figures
ax = axes([0.1, 0.1, 0.8, 0.8]) #dimensions for graph

explode=(0.048, 0, 0, 0)#creates popping effect for the graph

pie(fracs, explode=explode, labels=labels,
            autopct='%1.1f%%', shadow=True, startangle=90) #uses for creation shadow for 3D look and starts graph 

title('Relations to Technological Security Towards Lessening Crimes', bbox={'facecolor':'0.8', 'pad':5})# title and size for title box

show()#posts/creates graph